termp dummy test asset
